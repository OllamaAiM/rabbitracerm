#!/bin/bash
# ============================================================
#  rbitgm.sh — Rabbit Racer Installer for Raspberry Pi / Debian
#  Usage: sudo ./rbitgm.sh
# ============================================================
set -e

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
B='\033[0;34m'; M='\033[0;35m'; C='\033[0;36m'; N='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REAL_USER="${SUDO_USER:-$USER}"
USER_HOME=$(eval echo "~$REAL_USER")
INSTALL_DIR="$USER_HOME/rabbit_racer"
VENV_DIR="$USER_HOME/rabbit_racer_env"
APPS_DIR="$USER_HOME/.local/share/applications"
BIN_PATH="$INSTALL_DIR/bin/rabbit-racer"
UNINSTALL_PATH="$INSTALL_DIR/uninstall_rabbit_racer.sh"

banner() {
printf "${Y}"
cat << 'ART'
  ____  __   __  ____  ____  _____  __  _  _
 (  _ \(  ) (  )(_  _)/ ___)(  _  )(  )( \/ )
  )   / )(__ )(__ _)(_ \___ \ )(_)(  )(  )  (
 (__\_)(____)(____)____)(____/(_____)(__)(_/\_)
        ____  __   ___  ____  ____
       (  _ \(  ) / __)( ___)( ___)
        )   / )(( (__  )__)  )__)
       (__\_)(__)\___)(____)(__)
ART
printf "${N}\n"
echo -e "  ${C}Rabbit Racer — Raspberry Pi Installer${N}"
echo -e "  ${B}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}\n"
}

step() { echo -e "\n${G}[${1}/${STEPS}]${N} ${C}${2}${N}"; }
ok()   { echo -e "  ${G}✔${N} ${1}"; }
warn() { echo -e "  ${Y}⚠${N}  ${1}"; }
fail() { echo -e "\n${R}✘ ERROR: ${1}${N}\n"; exit 1; }

STEPS=7
banner

# ── 0. Root check ──────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  fail "Please run with sudo: sudo ./rbitgm.sh"
fi
ok "Running as root (user: $REAL_USER)"

# ── 1. System packages ─────────────────────────────────────
step 1 "Installing system dependencies (no Python — already on Pi)"
apt-get update -qq 2>/dev/null
apt-get install -y -qq \
  python3-pip python3-venv python3-dev \
  libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev \
  libportmidi-dev libjpeg-dev libfreetype6-dev \
  binutils upx-ucl patchelf 2>/dev/null
ok "System packages installed"

# ── 2. Python venv + pip ───────────────────────────────────
step 2 "Creating virtual environment & installing pip"
sudo -u "$REAL_USER" python3 -m venv "$VENV_DIR"
sudo -u "$REAL_USER" "$VENV_DIR/bin/pip" install -q --upgrade pip setuptools wheel
ok "Virtualenv ready at $VENV_DIR"

# ── 3. pip packages ────────────────────────────────────────
step 3 "Installing pygame + pyinstaller inside venv"
sudo -u "$REAL_USER" "$VENV_DIR/bin/pip" install -q pygame pyinstaller
ok "pygame & pyinstaller installed"

# ── 4. Copy game & build with PyInstaller ─────────────────
step 4 "Building standalone executable with PyInstaller"
mkdir -p "$INSTALL_DIR"
cp "$SCRIPT_DIR/game.py" "$INSTALL_DIR/game.py"
chown -R "$REAL_USER":"$REAL_USER" "$INSTALL_DIR"

echo -e "  ${Y}This may take 1-3 minutes on Raspberry Pi...${N}"

sudo -u "$REAL_USER" "$VENV_DIR/bin/pyinstaller" \
  --onefile \
  --name "rabbit-racer" \
  --distpath "$INSTALL_DIR/bin" \
  --workpath "$INSTALL_DIR/build" \
  --specpath "$INSTALL_DIR" \
  --hidden-import pygame \
  --hidden-import pygame.mixer \
  --hidden-import pygame.font \
  --hidden-import pygame.draw \
  --hidden-import pygame.transform \
  --collect-all pygame \
  --noconfirm \
  --clean \
  "$INSTALL_DIR/game.py" 2>&1 | grep -E "^(INFO|WARNING|ERROR|Building)" || true

[ -f "$BIN_PATH" ] || fail "PyInstaller build failed — binary not found at $BIN_PATH"
chmod +x "$BIN_PATH"
chown "$REAL_USER":"$REAL_USER" "$BIN_PATH"
ok "Binary built: $BIN_PATH ($(du -sh "$BIN_PATH" | cut -f1))"

# Clean build artifacts
rm -rf "$INSTALL_DIR/build" "$INSTALL_DIR/rabbit-racer.spec"
ok "Build artifacts cleaned"

# ── 5. System-wide symlink ─────────────────────────────────
step 5 "Installing system command"
ln -sf "$BIN_PATH" /usr/local/bin/rabbit-racer
ok "Command available: rabbit-racer"

# ── 6. Create uninstaller ──────────────────────────────────
step 6 "Creating uninstaller"

cat > "$UNINSTALL_PATH" << UNEOF
#!/bin/bash
# ============================================================
#  uninstall_rabbit_racer.sh — Rabbit Racer Uninstaller
#  Usage: sudo ./uninstall_rabbit_racer.sh
# ============================================================
set -e

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
C='\033[0;36m'; N='\033[0m'

REAL_USER="\${SUDO_USER:-\$USER}"
USER_HOME=\$(eval echo "~\$REAL_USER")
INSTALL_DIR="\$USER_HOME/rabbit_racer"
VENV_DIR="\$USER_HOME/rabbit_racer_env"
APPS_DIR="\$USER_HOME/.local/share/applications"
SELF="\$(readlink -f "\$0")"

if [ "\$EUID" -ne 0 ]; then
  echo -e "\${R}Please run with sudo: sudo \$0\${N}"
  exit 1
fi

echo -e "\n\${Y}Uninstalling Rabbit Racer...\${N}\n"

if [ -L /usr/local/bin/rabbit-racer ]; then
  rm -f /usr/local/bin/rabbit-racer
  echo -e "  \${G}✔\${N} Removed /usr/local/bin/rabbit-racer"
fi

if [ -L /usr/local/bin/rabbit-racer-uninstall ]; then
  rm -f /usr/local/bin/rabbit-racer-uninstall
  echo -e "  \${G}✔\${N} Removed /usr/local/bin/rabbit-racer-uninstall"
fi

if [ -f "\$APPS_DIR/rabbit-racer.desktop" ]; then
  rm -f "\$APPS_DIR/rabbit-racer.desktop"
  update-desktop-database "\$APPS_DIR" 2>/dev/null || true
  echo -e "  \${G}✔\${N} Removed desktop shortcut"
fi

if [ -d "\$VENV_DIR" ]; then
  rm -rf "\$VENV_DIR"
  echo -e "  \${G}✔\${N} Removed virtualenv at \$VENV_DIR"
fi

if [ -d "\$INSTALL_DIR" ]; then
  # Remove everything in install dir except self, then self
  find "\$INSTALL_DIR" -mindepth 1 ! -samefile "\$SELF" -delete 2>/dev/null || true
  echo -e "  \${G}✔\${N} Removed game files at \$INSTALL_DIR"
fi

echo ""
printf "\${G}"
cat << 'DONE'
  ╔══════════════════════════════════════════╗
  ║   ✅  Rabbit Racer uninstalled!          ║
  ╚══════════════════════════════════════════╝
DONE
printf "\${N}"

# Self-delete last — remove script and its parent dir if now empty
echo -e "  \${C}Removing uninstaller itself...\${N}"
PARENT_DIR="\$(dirname "\$SELF")"
rm -f "\$SELF"
rmdir "\$PARENT_DIR" 2>/dev/null || true
echo -e "  \${G}✔\${N} Uninstaller removed"
UNEOF

chmod +x "$UNINSTALL_PATH"
chown "$REAL_USER":"$REAL_USER" "$UNINSTALL_PATH"
ln -sf "$UNINSTALL_PATH" /usr/local/bin/rabbit-racer-uninstall
ok "Uninstaller created: $UNINSTALL_PATH"
ok "Command available:   rabbit-racer-uninstall"

# ── 7. Desktop shortcut in Games ──────────────────────────
step 7 "Creating Games menu shortcut"
sudo -u "$REAL_USER" mkdir -p "$APPS_DIR"

cat > "$APPS_DIR/rabbit-racer.desktop" << DESKEOF
[Desktop Entry]
Name=Rabbit Racer
GenericName=Arcade Game
Comment=Dodge cars as a pixelated rabbit! Cheat: scroll-click x5 + scroll up
Exec=$BIN_PATH
Icon=applications-games
Type=Application
Categories=Game;ArcadeGame;
Terminal=false
StartupNotify=true
Keywords=rabbit;racer;arcade;dodge;car;pixel;
DESKEOF

chmod +x "$APPS_DIR/rabbit-racer.desktop"
chown "$REAL_USER":"$REAL_USER" "$APPS_DIR/rabbit-racer.desktop"
update-desktop-database "$APPS_DIR" 2>/dev/null || true
ok "Shortcut created in Games menu"

# ── Done ───────────────────────────────────────────────────
echo ""
printf "${G}"
cat << 'DONE'
  ╔══════════════════════════════════════════╗
  ║   ✅  Rabbit Racer installed!            ║
  ╚══════════════════════════════════════════╝
DONE
printf "${N}"
echo -e "  ${C}Launch options:${N}"
echo -e "   • Terminal:   ${Y}rabbit-racer${N}"
echo -e "   • Direct:     ${Y}$BIN_PATH${N}"
echo -e "   • App menu:   ${Y}Games → Rabbit Racer${N}\n"
echo -e "  ${C}Controls:${N}  Mouse to steer  |  Dodge cars  |  Grab coins"
echo -e "  ${C}Cheat:${N}     Middle-click ×5  then  Scroll Up\n"
echo -e "  ${C}Uninstall:${N} ${Y}sudo rabbit-racer-uninstall${N}"
echo -e "             ${Y}sudo $UNINSTALL_PATH${N}\n"