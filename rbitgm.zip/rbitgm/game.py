#!/usr/bin/env python3
"""
Rabbit Racer v4 — Full debug + upgrade pass.
Controls: LMB=accelerate  RMB=brake  Mouse=steer
Cheat   : Middle-click ×5 then scroll-up
"""
import pygame, sys, random, math, os, json, time

# ── Pi / headless guard ──────────────────────────────────────
if "DISPLAY" not in os.environ and sys.platform not in ("win32","darwin"):
    os.environ.setdefault("DISPLAY", ":0")

pygame.init()
try:
    pygame.mixer.init(22050, -16, 1, 512)
    HAS_SND = True
except Exception:
    HAS_SND = False

PG2 = pygame.version.vernum[0] >= 2

# ── Logical canvas (never changes) ──────────────────────────
GAME_W, GAME_H = 240, 360
canvas = pygame.Surface((GAME_W, GAME_H))
clock  = pygame.time.Clock()
FPS    = 60

# ── Window (RESIZABLE — maximize never crashes) ──────────────
WIN_W, WIN_H = 720, 1080
screen = pygame.display.set_mode((WIN_W, WIN_H), pygame.RESIZABLE)
pygame.display.set_caption("Rabbit Racer")

# ── Dynamic letterbox ────────────────────────────────────────
def render_info():
    sw, sh = screen.get_size()
    sw = max(1, sw); sh = max(1, sh)          # guard div-by-zero on minimise
    sc = min(sw / GAME_W, sh / GAME_H)
    sc = max(0.5, sc)                          # minimum 0.5× scale
    w, h = int(GAME_W * sc), int(GAME_H * sc)
    return (sw - w) // 2, (sh - h) // 2, sc

def game_mouse():
    sx, sy = pygame.mouse.get_pos()
    ox, oy, sc = render_info()
    gx = max(0, min(GAME_W, int((sx - ox) / sc)))
    gy = max(0, min(GAME_H, int((sy - oy) / sc)))
    return gx, gy

def blit_canvas(shk_x=0, shk_y=0):
    ox, oy, sc = render_info()
    sw, sh = screen.get_size()
    screen.fill((0, 0, 0))
    scaled = pygame.transform.scale(canvas, (int(GAME_W * sc), int(GAME_H * sc)))
    screen.blit(scaled, (ox + shk_x, oy + shk_y))

# ── Road geometry ────────────────────────────────────────────
ROAD_L  = 42;  ROAD_R = 198
ROAD_W  = ROAD_R - ROAD_L
N_LANES = 3
LANE_W  = ROAD_W // N_LANES
LANES   = [ROAD_L + LANE_W * i + LANE_W // 2 for i in range(N_LANES)]

# ── Speed constants ──────────────────────────────────────────
SPD_BASE  = 2.2;  SPD_MAX  = 9.0;  SPD_MIN  = 0.0
SPD_ACCEL = 0.20; SPD_BRAKE = 0.32; SPD_COAST = 0.05
STOP_DIST = 30

# ── Palette ──────────────────────────────────────────────────
BLACK  =(0,0,0);      WHITE  =(255,255,255); RED    =(210,50,50)
GREEN  =(50,190,50);  BLUE   =(50,100,210);  YELLOW =(240,210,50)
ORANGE =(230,140,40); GRAY   =(118,118,118); SKIN   =(255,200,155)
PINK   =(255,160,190);CREAM  =(230,225,205); ROTT_C =(38,28,18)
ROTT_T =(130,95,42);  ROAD_C =(78,78,78);   SIDE_C =(148,138,122)
GRASS_C=(55,150,45);  CHEAT_C=(255,60,255); DK_ROAD=(55,55,55)
NIGHT_SKY=(12,12,28); HEADLIGHT=(255,255,200)

# ── Car palettes per level ───────────────────────────────────
PALETTES = [
    [(200,50,50),(50,50,200),(50,180,50),(200,180,50),(160,50,180)],
    [(220,100,40),(80,50,200),(50,200,200),(180,50,180),(220,220,70)],
    [(220,220,220),(55,55,55),(200,150,50),(100,180,50),(50,150,200)],
    [(255,110,40),(110,40,255),(40,255,180),(255,40,110),(200,255,40)],
    [(255,200,80),(80,200,255),(200,80,255),(80,255,120),(255,80,180)],
]

# ── Font: Font(None) — works in PyInstaller; SysFont does NOT ─
def F(sz): return pygame.font.Font(None, max(8, sz))
def txt(dst, s, x, y, col, sz=9):
    r = F(sz).render(str(s), False, col); dst.blit(r, (x, y))

# ── Sounds ───────────────────────────────────────────────────
def _beep(freq=440, ms=50, vol=0.14, wave='sine'):
    if not HAS_SND: return None
    try:
        n = int(22050 * ms / 1000)
        if wave == 'sine':
            b = bytes([int(127 + 127 * math.sin(2*math.pi*freq*i/22050)) for i in range(n)])
        else:  # square
            b = bytes([200 if (i * freq // 22050) % 2 == 0 else 55 for i in range(n)])
        snd = pygame.mixer.Sound(buffer=b); snd.set_volume(vol); return snd
    except: return None

SND_COIN   = _beep(880,  40, 0.12)
SND_HIT    = _beep(110,  90, 0.20, 'square')
SND_LVL    = _beep(660, 130, 0.14)
SND_BRAKE  = _beep(200,  30, 0.08, 'square')
SND_ACCEL  = _beep(330,  25, 0.06)
SND_BONUS  = _beep(1046, 60, 0.14)

def play(s):
    if s:
        try: s.play()
        except: pass

# ═══════════════════════════════════════════════════════════════
#  DRAWING
# ═══════════════════════════════════════════════════════════════
def _dark(c, amt=55):  return tuple(max(0, v-amt) for v in c)
def _lite(c, amt=60):  return tuple(min(255, v+amt) for v in c)

def draw_road(dst, offset, night=False):
    rc  = DK_ROAD if night else ROAD_C
    sc  = (80,75,65) if night else SIDE_C
    gc  = (28,90,28) if night else GRASS_C
    # Grass
    pygame.draw.rect(dst, gc, (0,0,8,GAME_H))
    pygame.draw.rect(dst, gc, (GAME_W-8,0,8,GAME_H))
    # Sidewalk
    pygame.draw.rect(dst, sc, (8,0,ROAD_L-8,GAME_H))
    pygame.draw.rect(dst, sc, (ROAD_R,0,GAME_W-ROAD_R-8,GAME_H))
    # Kerb
    kerb = (60,55,48) if night else (105,96,84)
    pygame.draw.rect(dst, kerb, (ROAD_L-5,0,5,GAME_H))
    pygame.draw.rect(dst, kerb, (ROAD_R,  0,5,GAME_H))
    # Road
    pygame.draw.rect(dst, rc, (ROAD_L,0,ROAD_W,GAME_H))
    # Edge lines
    pygame.draw.rect(dst, WHITE, (ROAD_L,0,3,GAME_H))
    pygame.draw.rect(dst, WHITE, (ROAD_R-3,0,3,GAME_H))
    # Lane dashes
    DH,GAP = 14,8; TOT = DH+GAP
    dy = int(offset) % TOT
    for ln in range(1, N_LANES):
        lx = ROAD_L + LANE_W*ln - 1
        y  = -dy
        while y < GAME_H:
            pygame.draw.rect(dst, YELLOW, (lx, y, 2, DH)); y += TOT
    # Sidewalk joints
    joint = (60,55,48) if night else (100,92,80)
    for y0 in range(0,GAME_H,16):
        yo = (y0 - int(offset)%16) % GAME_H
        pygame.draw.rect(dst, joint, (8,yo,ROAD_L-8,1))
        pygame.draw.rect(dst, joint, (ROAD_R,yo,GAME_W-ROAD_R-8,1))
    # Grass blades
    for y0 in range(0,GAME_H,20):
        yo = (y0 - int(offset)%20) % GAME_H
        blade = (25,88,20) if night else (35,120,28)
        for gx in (2,5):               pygame.draw.rect(dst,blade,(gx,yo,1,4))
        for gx in (GAME_W-3,GAME_W-6): pygame.draw.rect(dst,blade,(gx,yo,1,4))

def draw_skid(dst, x, y, alpha=180):
    """Pixel skid mark strip."""
    s = pygame.Surface((4,10), pygame.SRCALPHA)
    s.fill((30,30,30,alpha))
    dst.blit(s, (x-2, y))

def draw_car(dst, cx, cy, color, ctype=0, flip=False, headlights=False):
    dims = [(16,24),(18,28),(14,22),(18,26),(20,24),(16,26),(20,28)]
    w,h  = dims[min(ctype, len(dims)-1)]
    bx,by= cx-w//2, cy-h//2
    dark = _dark(color); lite = _lite(color)
    # Body
    pygame.draw.rect(dst, color, (bx,by+4,w,h-8))
    # Roof
    pygame.draw.rect(dst, dark,  (bx+3,by+8,w-6,h-16))
    # Windows
    wc = (140,205,255)
    if flip:
        pygame.draw.rect(dst,wc,(bx+4,by+h-13,w-8,4))
        pygame.draw.rect(dst,wc,(bx+4,by+8,    w-8,4))
        tl_c = (255,80,80)   # tail lights (top when flipped)
        hl_c = HEADLIGHT if headlights else (255,255,130)
        pygame.draw.rect(dst,tl_c,(bx+2,by,   4,3))
        pygame.draw.rect(dst,tl_c,(bx+w-6,by, 4,3))
        pygame.draw.rect(dst,hl_c,(bx+2,by+h-3,4,3))
        pygame.draw.rect(dst,hl_c,(bx+w-6,by+h-3,4,3))
    else:
        pygame.draw.rect(dst,wc,(bx+4,by+8,    w-8,4))
        pygame.draw.rect(dst,wc,(bx+4,by+h-13, w-8,4))
        hl_c = HEADLIGHT if headlights else (255,255,120)
        tl_c = (255,60,60)
        pygame.draw.rect(dst,hl_c,(bx+2,by,   4,3))
        pygame.draw.rect(dst,hl_c,(bx+w-6,by, 4,3))
        pygame.draw.rect(dst,tl_c,(bx+2,by+h-3,4,3))
        pygame.draw.rect(dst,tl_c,(bx+w-6,by+h-3,4,3))
    # Wheels
    for wx,wy in [(bx-2,by+5),(bx+w-2,by+5),(bx-2,by+h-12),(bx+w-2,by+h-12)]:
        pygame.draw.rect(dst,(20,20,20),(wx,wy,4,7))
        pygame.draw.rect(dst,GRAY,     (wx+1,wy+2,2,3))
    # Shine stripe
    pygame.draw.rect(dst, lite, (bx+1,by+6,2,h-12))

def draw_player_car(dst, cx, cy, night=False, braking=False):
    color=(215,45,45); w,h=20,28; bx,by=cx-w//2,cy-h//2
    dark=(145,18,18); lite=(255,105,105)
    pygame.draw.rect(dst,color,(bx,by+4,w,h-8))
    pygame.draw.rect(dst,dark, (bx+3,by+8,w-6,h-16))
    pygame.draw.rect(dst,(165,220,255),(bx+4,by+8,   w-8,4))
    pygame.draw.rect(dst,(165,220,255),(bx+4,by+h-13,w-8,4))
    hl = HEADLIGHT if night else (255,255,120)
    pygame.draw.rect(dst,hl,(bx+2,by,   4,3)); pygame.draw.rect(dst,hl,(bx+w-6,by,4,3))
    tl = (255,20,20) if braking else (200,30,30)
    pygame.draw.rect(dst,tl,(bx+2,by+h-3,4,3)); pygame.draw.rect(dst,tl,(bx+w-6,by+h-3,4,3))
    for wx,wy in [(bx-2,by+5),(bx+w-2,by+5),(bx-2,by+h-12),(bx+w-2,by+h-12)]:
        pygame.draw.rect(dst,(20,20,20),(wx,wy,4,7)); pygame.draw.rect(dst,GRAY,(wx+1,wy+2,2,3))
    pygame.draw.rect(dst,lite,(bx+1,by+6,2,h-12))
    pygame.draw.rect(dst,WHITE,(bx+5,by+h-4,w-10,3))
    pygame.draw.rect(dst,(50,50,200),(bx+6,by+h-3,w-12,1))
    # Rabbit driver (left seat)
    rx,ry = cx-4, cy-3
    for ex,ew in [(-1,2),(2,2)]:  # ears
        pygame.draw.rect(dst,CREAM,(rx+ex,ry-14,ew,8))
    pygame.draw.rect(dst,PINK,(rx,  ry-13,1,6)); pygame.draw.rect(dst,PINK,(rx+3,ry-13,1,6))
    pygame.draw.rect(dst,CREAM,(rx-2,ry-8,6,6))
    pygame.draw.rect(dst,(185,38,38),(rx,  ry-7,1,1))
    pygame.draw.rect(dst,(185,38,38),(rx+3,ry-7,1,1))
    pygame.draw.rect(dst,PINK, (rx+1,ry-6,2,1))
    pygame.draw.rect(dst,BLUE, (rx-2,ry-2,5,5)); pygame.draw.rect(dst,WHITE,(rx-1,ry-1,3,3))
    # Rottweiler passenger (right seat)
    dx,dy2 = cx+4, cy-3
    pygame.draw.rect(dst,ROTT_C,(dx-4,dy2-9,2,3)); pygame.draw.rect(dst,ROTT_C,(dx+3,dy2-9,2,3))
    pygame.draw.rect(dst,ROTT_C,(dx-3,dy2-9,6,5))
    pygame.draw.rect(dst,ROTT_T,(dx-2,dy2-8,4,2)); pygame.draw.rect(dst,ROTT_T,(dx-2,dy2-5,4,2))
    pygame.draw.rect(dst,(175,135,38),(dx-2,dy2-8,1,1)); pygame.draw.rect(dst,(175,135,38),(dx+1,dy2-8,1,1))
    pygame.draw.rect(dst,ROTT_C,(dx-3,dy2-4,6,5)); pygame.draw.rect(dst,ROTT_T,(dx-1,dy2-3,3,3))

def draw_stop_sign(dst, cx, cy):
    pygame.draw.rect(dst,(120,120,120),(cx-1,cy+7,3,14))
    for rx,rw in [(-7,14),(-5,10)]:
        for ry,rh in [(-6,13),(-9,19)]:
            pygame.draw.rect(dst,RED,(cx+rx,cy+ry,rw,rh))
    pygame.draw.rect(dst,WHITE,(cx-5,cy-4,10,9)); pygame.draw.rect(dst,WHITE,(cx-3,cy-6,6,13))
    pygame.draw.rect(dst,RED,  (cx-4,cy-3,8,7));  pygame.draw.rect(dst,RED,  (cx-2,cy-5,4,11))
    txt(dst,"STOP",cx-8,cy-2,WHITE,8)

def draw_traffic_light(dst, cx, cy, state, night=False):
    # Post
    pygame.draw.rect(dst,(100,100,100),(cx-1,cy+22,3,22))
    # Housing
    pygame.draw.rect(dst,(18,18,18),(cx-7,cy-22,14,45))
    pygame.draw.rect(dst,(32,32,32),(cx-6,cy-21,12,43))
    # Visor shade
    for yo in (-19,-8,3):
        pygame.draw.rect(dst,(12,12,12),(cx-7,cy+yo,14,2))
    rc = (220,40,40)   if state==0 else (35,4,4)
    yc = (230,195,30)  if state==1 else (42,36,4)
    gc = (38,205,38)   if state==2 else (4,40,4)
    for c,yo in [(rc,-18),(yc,-7),(gc,4)]:
        pygame.draw.rect(dst,c,(cx-5,cy+yo,10,9))
        if c not in [(35,4,4),(42,36,4),(4,40,4)]:
            # glow highlight top-left
            pygame.draw.rect(dst,_lite(c,80),(cx-4,cy+yo+1,4,3))
    # Night glow radius
    if night and state in (0,2):
        col = (60,0,0) if state==0 else (0,55,0)
        for dx in range(-10,11):
            for dy2 in range(-10,11):
                if 7 < dx*dx+dy2*dy2 < 100:
                    gx = cx+dx; gy = cy+(-18 if state==0 else 4)+4+dy2
                    if 0<=gx<GAME_W and 0<=gy<GAME_H:
                        p = canvas.get_at((gx,gy))
                        canvas.set_at((gx,gy),(min(255,p[0]+col[0]),min(255,p[1]+col[1]),min(255,p[2]+col[2])))

def draw_zebra(dst, y, night=False):
    sw = 7
    c  = (200,200,200) if night else WHITE
    for lx in range(ROAD_L, ROAD_R, sw*2):
        pygame.draw.rect(dst,c,(lx,y,sw,11))
    # Pedestrian crossing sign on right
    txt(dst,"✕",ROAD_R+4,y+1,(180,180,60) if night else (140,140,50),9)

def draw_ped(dst, cx, cy, anim, skin, shirt, night=False):
    lo=[0,2,0,-2][anim%4]
    leg_c = (25,25,90) if not night else (15,15,60)
    pygame.draw.rect(dst,leg_c,(cx-2,cy+3,2,5+lo))
    pygame.draw.rect(dst,leg_c,(cx+1,cy+3,2,5-lo))
    pygame.draw.rect(dst,(22,14,6),(cx-3,cy+7+lo,3,2))
    pygame.draw.rect(dst,(22,14,6),(cx+1,cy+7-lo,3,2))
    pygame.draw.rect(dst,shirt,   (cx-3,cy-4,7,7))
    pygame.draw.rect(dst,skin,    (cx-5,cy-3+lo,3,4))
    pygame.draw.rect(dst,skin,    (cx+3,cy-3-lo,3,4))
    pygame.draw.rect(dst,skin,    (cx-2,cy-9,5,5))
    pygame.draw.rect(dst,(60,30,6),(cx-3,cy-11,7,2))
    pygame.draw.rect(dst,(60,30,6),(cx-2,cy-13,5,3))
    pygame.draw.rect(dst,BLACK,   (cx-1,cy-8,1,1))
    pygame.draw.rect(dst,BLACK,   (cx+2,cy-8,1,1))

def draw_powerup(dst, cx, cy, kind, anim):
    off = 1 if (anim//4)%2 else 0
    if kind == 'shield':
        pygame.draw.rect(dst,(50,150,255),(cx-5,cy-7+off,10,12))
        pygame.draw.rect(dst,(100,200,255),(cx-3,cy-5+off,6,8))
        txt(dst,"S",cx-4,cy-5+off,(255,255,255),10)
    elif kind == 'slow':
        pygame.draw.rect(dst,(200,80,255),(cx-5,cy-6+off,10,10))
        txt(dst,"T",cx-4,cy-4+off,(255,255,255),10)
    elif kind == 'x2':
        pygame.draw.rect(dst,(255,200,30),(cx-5,cy-6+off,10,10))
        txt(dst,"x2",cx-6,cy-4+off,(0,0,0),9)

# ═══════════════════════════════════════════════════════════════
#  PARTICLES / POPUPS / SKIDMARKS
# ═══════════════════════════════════════════════════════════════
class Particle:
    __slots__=('x','y','vx','vy','life','ml','col','sz')
    def __init__(self,x,y,col,spd=2.5,life=22,sz=2):
        self.x=float(x);self.y=float(y);self.col=col;self.life=life;self.ml=life;self.sz=sz
        a=random.uniform(0,math.tau);s=random.uniform(.3,spd)
        self.vx=math.cos(a)*s;self.vy=math.sin(a)*s
    def update(self): self.x+=self.vx;self.y+=self.vy;self.vy+=.10;self.life-=1
    def draw(self,dst):
        sz=max(1,int(self.sz*self.life/self.ml))
        pygame.draw.rect(dst,self.col[:3],(int(self.x),int(self.y),sz,sz))

class Popup:
    def __init__(self,x,y,t,col,big=False):
        self.x=float(x);self.y=float(y);self.t=t;self.col=col
        self.life=42;self.ml=42;self.big=big
    def update(self): self.y-=.55;self.life-=1
    def draw(self,dst):
        a=max(0,int(255*self.life/self.ml))
        s=F(13 if self.big else 9).render(self.t,False,self.col)
        s.set_alpha(a);dst.blit(s,(int(self.x)-s.get_width()//2,int(self.y)))

class Skidmark:
    def __init__(self,x,y): self.x=x;self.y=y;self.life=120
    def update(self,cs): self.y+=cs*0.3;self.life-=1
    def draw(self,dst):
        a=max(0,min(130,self.life))
        s=pygame.Surface((4,8),pygame.SRCALPHA);s.fill((20,20,20,a));dst.blit(s,(self.x-2,self.y))

# ═══════════════════════════════════════════════════════════════
#  GAME OBJECTS
# ═══════════════════════════════════════════════════════════════
class Player:
    W,H=20,28
    def __init__(self):
        self.x=float(GAME_W//2);self.y=float(GAME_H-58)
        self.shield=0  # frames of shield remaining
    def update(self,gmx):
        tx=max(ROAD_L+self.W//2+4, min(ROAD_R-self.W//2-4, gmx))
        self.x+=(tx-self.x)*0.20
        if self.shield>0: self.shield-=1
    def rect(self):
        return pygame.Rect(int(self.x)-self.W//2+4,int(self.y)-self.H//2+4,self.W-8,self.H-8)
    def draw(self,dst,night=False,braking=False):
        draw_player_car(dst,int(self.x),int(self.y),night,braking)
        if self.shield>0:
            a=min(200,self.shield*4)
            s=pygame.Surface((28,36),pygame.SRCALPHA)
            pygame.draw.rect(s,(50,150,255,a),(0,0,28,36),2)
            dst.blit(s,(int(self.x)-14,int(self.y)-18))

class Enemy:
    def __init__(self,lvl,lane):
        self.lane=lane; self.x=float(LANES[lane]); self.y=-34.0
        self.w,self.h=18,26
        pal=PALETTES[min(lvl-1,len(PALETTES)-1)]
        self.color=random.choice(pal)
        self.ctype=random.randint(0,min(lvl+1,6))
        self.base_spd=random.uniform(1.4,2.8+(lvl-1)*0.42)
        self.eff_spd=self.base_spd
        self.stopped=False; self.stop_timer=0; self.passed=False
    def update(self,cam_spd,stop_lines):
        front=self.y+self.h//2
        should_stop=any(active and 0<(sly-front)<STOP_DIST+14 for sly,active in stop_lines)
        if should_stop and not self.stopped:
            self.eff_spd=max(0,self.eff_spd-0.22)
            if self.eff_spd==0: self.stopped=True; self.stop_timer=0
        elif self.stopped:
            self.stop_timer+=1
            past=all((not active) or (sly-front)>4 for sly,active in stop_lines)
            if past or self.stop_timer>300: self.stopped=False; self.eff_spd=self.base_spd
        else:
            self.eff_spd=min(self.base_spd,self.eff_spd+0.15)
        if not self.stopped:
            self.y+=self.eff_spd+cam_spd*0.72
    def rect(self):
        return pygame.Rect(int(self.x)-self.w//2+3,int(self.y)-self.h//2+3,self.w-6,self.h-6)
    def draw(self,dst,night=False):
        draw_car(dst,int(self.x),int(self.y),self.color,self.ctype,True,night)

class Coin:
    def __init__(self):
        self.x=float(LANES[random.randint(0,2)]+random.randint(-8,8))
        self.y=-12.0;self.r=4;self.anim=0
    def update(self,cs): self.y+=1.6+cs*0.45;self.anim=(self.anim+1)%8
    def rect(self): return pygame.Rect(int(self.x)-self.r,int(self.y)-self.r,self.r*2,self.r*2)
    def draw(self,dst):
        cx,cy=int(self.x),int(self.y);off=1 if self.anim<4 else 0
        pygame.draw.rect(dst,(208,188,42),(cx-3,cy-4+off,6,7))
        pygame.draw.rect(dst,(255,238,96),(cx-2,cy-5+off,4,1))
        pygame.draw.rect(dst,(255,238,96),(cx-2,cy+2+off,4,1))
        pygame.draw.rect(dst,(155,135,16),(cx-4,cy-2+off,1,3))
        pygame.draw.rect(dst,(155,135,16),(cx+3,cy-2+off,1,3))
        pygame.draw.rect(dst,(148,126,12),(cx-1,cy-3+off,2,5))

class PowerUp:
    KINDS=['shield','slow','x2']
    def __init__(self):
        self.kind=random.choice(self.KINDS)
        self.x=float(LANES[random.randint(0,2)])
        self.y=-16.0; self.r=7; self.anim=0
    def update(self,cs): self.y+=1.4+cs*0.4;self.anim+=1
    def rect(self): return pygame.Rect(int(self.x)-self.r,int(self.y)-self.r,self.r*2,self.r*2)
    def draw(self,dst): draw_powerup(dst,int(self.x),int(self.y),self.kind,self.anim)

class StopSign:
    def __init__(self):
        self.x=float(random.choice([ROAD_L-14,ROAD_R+14]))
        self.y=float(random.randint(-90,-50))
    def update(self,cs): self.y+=1.6+cs*0.4
    def draw(self,dst): draw_stop_sign(dst,int(self.x),int(self.y))

class TrafficLight:
    DUR=[180,65,200]
    def __init__(self):
        self.x=float(ROAD_R+13); self.y=float(random.randint(-130,-80))
        self.state=0; self.timer=random.randint(0,60)
    @property
    def stop_line_y(self): return self.y+22
    @property
    def active(self): return self.state in (0,1)
    def update(self,cs):
        self.y+=cs; self.timer+=1
        if self.timer>=self.DUR[self.state]: self.state=(self.state+1)%3; self.timer=0
    def draw(self,dst,night=False):
        draw_traffic_light(dst,int(self.x),int(self.y),self.state,night)
        if self.active:
            col=RED if self.state==0 else (215,175,28)
            pygame.draw.rect(dst,col,(ROAD_L,int(self.stop_line_y),ROAD_W,2))

class ZebraCrossing:
    DUR=[200,60,170]
    def __init__(self):
        self.x=float(ROAD_R+13); self.y=float(random.randint(-160,-100))
        self.state=0; self.timer=random.randint(0,80); self.peds=[]
    @property
    def crossing_y(self): return self.y+20
    @property
    def stop_line_y(self): return self.y+18
    @property
    def active(self): return self.state in (0,1)
    def has_ped_on_road(self):
        return any(ROAD_L-4<p.x<ROAD_R+4 for p in self.peds)
    def update(self,cs):
        prev=self.state; self.y+=cs; self.timer+=1
        if self.timer>=self.DUR[self.state]: self.state=(self.state+1)%3; self.timer=0
        if prev!=0 and self.state==0:
            for i in range(random.randint(2,5)):
                self.peds.append(ZebraPed(ROAD_R+18,self.crossing_y+random.randint(-2,2),i*26))
        for p in self.peds[:]:
            p.update(cs)
            if p.done: self.peds.remove(p)
    def draw(self,dst,night=False):
        draw_zebra(dst,int(self.crossing_y),night)
        draw_traffic_light(dst,int(self.x),int(self.y),self.state,night)
        if self.active:
            col=RED if self.state==0 else (215,175,28)
            pygame.draw.rect(dst,col,(ROAD_L,int(self.stop_line_y),ROAD_W,2))
        for p in self.peds: p.draw(dst)

class ZebraPed:
    SHIRTS=[(200,50,50),(50,50,200),(50,180,50),(220,180,50),(180,50,200),(50,200,200)]
    SKINS=[SKIN,(205,160,105),(145,105,62),(255,225,185)]
    def __init__(self,x,y,delay=0):
        self.x=float(x);self.y=float(y);self.delay=delay;self.done=False
        self.anim=0;self.at=0;self.shirt=random.choice(self.SHIRTS);self.skin=random.choice(self.SKINS)
    def update(self,cs):
        self.y+=cs
        if self.delay>0: self.delay-=1; return
        self.x-=0.7; self.at+=1
        if self.at>=6: self.anim=(self.anim+1)%4;self.at=0
        if self.x<ROAD_L-24: self.done=True
    def draw(self,dst):
        if self.delay>0: return
        draw_ped(dst,int(self.x),int(self.y),self.anim,self.skin,self.shirt)

class SidePed:
    """Sidewalk pedestrians that bounce within their sidewalk strip.
    BUG FIX: direction logic now checks the correct boundary for each side."""
    SHIRTS=[(200,50,50),(50,50,200),(50,180,50),(220,180,50),(180,50,200),(50,200,200),(200,200,50)]
    SKINS=[SKIN,(205,160,105),(145,105,62),(255,225,185)]
    def __init__(self):
        self.side=random.choice([-1,1])   # -1=left sidewalk  +1=right sidewalk
        if self.side==-1:
            # Left sidewalk: x range [8 .. ROAD_L-5]
            self.x=float(random.randint(10,ROAD_L-8))
            self.dir=random.choice([-1,1])
            self.xmin,self.xmax=9,ROAD_L-6
        else:
            # Right sidewalk: x range [ROAD_R+5 .. GAME_W-8]
            self.x=float(random.randint(ROAD_R+6,GAME_W-10))
            self.dir=random.choice([-1,1])
            self.xmin,self.xmax=ROAD_R+5,GAME_W-9
        self.y=float(random.randint(20,GAME_H-80))
        self.xspd=random.uniform(0.28,0.58)
        self.anim=0;self.at=0;self.done=False
        self.shirt=random.choice(self.SHIRTS);self.skin=random.choice(self.SKINS)
    def update(self,cs):
        self.y+=cs            # scroll with world
        self.x+=self.xspd*self.dir
        if self.x<self.xmin: self.x=float(self.xmin); self.dir=1
        if self.x>self.xmax: self.x=float(self.xmax); self.dir=-1
        self.at+=1
        if self.at>=7: self.anim=(self.anim+1)%4;self.at=0
        if self.y>GAME_H+30: self.done=True
    def draw(self,dst): draw_ped(dst,int(self.x),int(self.y),self.anim,self.skin,self.shirt)

# ═══════════════════════════════════════════════════════════════
#  HUD
# ═══════════════════════════════════════════════════════════════
def draw_hud(dst,gs):
    # Speed bar + numeric
    bw=40; bh=6
    bfill=int((gs.cam_spd/SPD_MAX)*bw)
    pygame.draw.rect(dst,(35,35,35),(GAME_W-46,GAME_H-14,bw+2,bh+2))
    bc=(50,220,50) if gs.cam_spd<3.5 else (220,185,40) if gs.cam_spd<6.5 else (220,50,50)
    pygame.draw.rect(dst,bc,(GAME_W-45,GAME_H-13,max(0,bfill),bh))
    txt(dst,f"{gs.cam_spd:.1f}",GAME_W-46,GAME_H-22,(185,185,185),8)
    # Score
    txt(dst,f"SC:{gs.score:05d}",2,2,WHITE,9)
    txt(dst,f"C:{gs.coins}",2,12,YELLOW,9)
    txt(dst,f"L:{gs.level}",GAME_W-28,2,(100,255,100),9)
    txt(dst,f"HI:{gs.hi}",GAME_W-52,12,(180,180,255),8)
    # Lives as pixel hearts
    for i in range(min(gs.lives,7)):
        hx=2+i*11;hy=23
        for dx,dyw,dw in[(1,0,3),(5,0,3),(0,1,9),(1,4,7),(2,5,5),(3,6,3),(4,7,1)]:
            pygame.draw.rect(dst,RED,(hx+dx,hy+dyw,dw,1))
    # x2 coin multiplier
    if gs.coin_x2>0:
        txt(dst,f"x2 {gs.coin_x2//60+1}s",2,33,YELLOW,8)
    # Slow traffic
    if gs.slow_t>0:
        txt(dst,"SLOW",2,42,(180,80,255),8)
    # Shield
    if gs.player.shield>0:
        txt(dst,"SHIELD",GAME_W//2-20,2,(80,160,255),8)
    # Cheat
    if gs.cheat: txt(dst,"CHEAT!",GAME_W//2-20,2,CHEAT_C,9)
    # Red light warning
    if gs.stop_warn>0:
        a=min(30,gs.stop_warn)
        c=(255,int(255*a/30),int(255*a/30))
        txt(dst,"◼ RED LIGHT",GAME_W//2-30,GAME_H//2-8,c,9)
        txt(dst,"BRAKE: RMB",GAME_W//2-26,GAME_H//2+2,(200,200,200),8)
    # Level-up banner
    if gs.lvlup_t>0:
        txt(dst,f"LEVEL {gs.level}!",GAME_W//2-28,GAME_H//2-35,YELLOW,13)
    # Night mode indicator
    if gs.night:
        txt(dst,"NIGHT",GAME_W-30,GAME_H-26,(100,100,200),8)
    if gs.paused:
        txt(dst,"PAUSED  [P]",GAME_W//2-30,GAME_H//2-6,WHITE,12)

def draw_game_over(dst,gs):
    ov=pygame.Surface((GAME_W,GAME_H),pygame.SRCALPHA);ov.fill((0,0,0,170));dst.blit(ov,(0,0))
    txt(dst,"GAME OVER",GAME_W//2-38,GAME_H//2-60,RED,16)
    for i,(t,c) in enumerate([(f"SCORE  {gs.score:05d}",WHITE),(f"COINS  {gs.coins}",YELLOW),
                               (f"LEVEL  {gs.level}",(100,255,100)),(f"BEST   {gs.hi}",(180,180,255)),
                               ("",""),("CLICK  TO  PLAY",WHITE)]):
        if t: txt(dst,t,GAME_W//2-34,GAME_H//2-32+i*13,c,9)

def draw_title(dst,off,tick):
    draw_road(dst,off)
    ov=pygame.Surface((GAME_W,GAME_H),pygame.SRCALPHA);ov.fill((0,0,22,178));dst.blit(ov,(0,0))
    txt(dst,"RABBIT",GAME_W//2-34,44,YELLOW,18)
    txt(dst,"RACER", GAME_W//2-27,63,YELLOW,18)
    draw_player_car(dst,GAME_W//2,118)
    hi=load_hi()
    for y,(t,c) in zip([150,162,175,192,210],[
        ("MOUSE  TO  STEER",WHITE),
        ("LMB=ACCEL  RMB=BRAKE",YELLOW),
        ("DODGE CARS  GRAB COINS",(180,255,180)),
        ("CLICK  TO  START",(100,255,100)),
        (f"BEST: {hi}",(180,180,255))]):
        txt(dst,t,GAME_W//2-len(t)*3,y,c,9)
    txt(dst,"CHEAT: MID-CLICK x5 + SCROLL UP",2,GAME_H-14,(100,100,200),7)

# ═══════════════════════════════════════════════════════════════
#  HIGH SCORE
# ═══════════════════════════════════════════════════════════════
SAVE=os.path.join(os.path.expanduser("~"),".rbitgm_save.json")
def load_hi():
    try:
        with open(SAVE) as f: return json.load(f).get("hi",0)
    except: return 0
def save_hi(v):
    try:
        with open(SAVE,"w") as f: json.dump({"hi":v},f)
    except: pass

# ═══════════════════════════════════════════════════════════════
#  GAME STATE
# ═══════════════════════════════════════════════════════════════
class GS:
    def __init__(self,hi=0):
        self.score=0;self.coins=0;self.level=1;self.lives=3;self.hi=hi
        self.cam_spd=SPD_BASE;self.road_off=0.0
        self.player=Player()
        self.enemies=[];self.coinlist=[];self.powerups=[]
        self.signs=[];self.lights=[];self.zebras=[];self.side_peds=[]
        self.particles=[];self.popups=[];self.skids=[]
        self.sp_t=0;self.co_t=0;self.pd_t=0;self.zb_t=0;self.lt_t=0;self.pu_t=0
        self.inv=0;self.flash=False;self.flash_t=0
        self.shake=0;self.sx=0;self.sy=0
        self.game_over=False;self.paused=False;self.lvlup_t=0
        self.stop_warn=0;self.coin_x2=0;self.slow_t=0
        self.night=False;self.night_t=0
        self.cheat=False;self.sc_clicks=0;self.sc_last=0;self.cheat_step=0
        self._rlanes=[]   # recent spawn lanes

# ═══════════════════════════════════════════════════════════════
#  CHEAT CODE (pygame 1 & 2)
# ═══════════════════════════════════════════════════════════════
def cheat_event(gs,ev):
    now=pygame.time.get_ticks()
    if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==2:
        if now-gs.sc_last>5000: gs.sc_clicks=0
        gs.sc_clicks+=1;gs.sc_last=now
        if gs.sc_clicks>=5: gs.cheat_step=1
    sup=False
    if PG2:
        if ev.type==pygame.MOUSEWHEEL and ev.y>0: sup=True
    else:
        if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==4: sup=True
    if gs.cheat_step==1 and sup:
        gs.cheat=not gs.cheat;gs.cheat_step=0;gs.sc_clicks=0
        if gs.cheat:
            gs.coins+=999;gs.lives=99;gs.score+=9999
            gs.player.shield=600
            gs.popups.append(Popup(GAME_W//2,GAME_H//2,"CHEAT ON!",CHEAT_C,True))

# ═══════════════════════════════════════════════════════════════
#  UPDATE
# ═══════════════════════════════════════════════════════════════
def update(gs,gmx,lmb,rmb):
    if gs.paused: return

    # ── Steering ────────────────────────────────────────────
    gs.player.update(gmx)

    # ── Speed control (LMB=accel, RMB=brake) ────────────────
    was_braking=gs.cam_spd>SPD_BASE+0.5
    slow_mult=0.55 if gs.slow_t>0 else 1.0
    if lmb and not rmb:
        top=min(SPD_MAX+(gs.level-1)*0.28,SPD_MAX*1.5)*(slow_mult)
        gs.cam_spd=min(top, gs.cam_spd+SPD_ACCEL)
    elif rmb and not lmb:
        gs.cam_spd=max(SPD_MIN, gs.cam_spd-SPD_BRAKE)
        if gs.cam_spd<SPD_BASE-0.5 and was_braking: play(SND_BRAKE)
    else:
        if gs.cam_spd>SPD_BASE*slow_mult:
            gs.cam_spd=max(SPD_BASE*slow_mult,gs.cam_spd-SPD_COAST)
        elif gs.cam_spd<SPD_BASE*slow_mult:
            gs.cam_spd=min(SPD_BASE*slow_mult,gs.cam_spd+SPD_COAST)
    if gs.cheat: gs.cam_spd=min(gs.cam_spd,SPD_BASE+0.6)

    # Skid marks while braking hard
    if rmb and gs.cam_spd<SPD_BASE and (int(gs.road_off)%6==0):
        for off in (-5,5):
            gs.skids.append(Skidmark(int(gs.player.x)+off,int(gs.player.y)+10))

    gs.road_off=(gs.road_off+gs.cam_spd)%100000
    gs.score+=1; gs.hi=max(gs.hi,gs.score)

    # Night mode: activates after level 5
    if gs.level>=6 and not gs.night:
        gs.night=True
    if gs.level<6: gs.night=False

    # Timers
    if gs.coin_x2>0: gs.coin_x2-=1
    if gs.slow_t>0:  gs.slow_t-=1
    if gs.lvlup_t>0: gs.lvlup_t-=1

    # Level up
    if gs.coins>=gs.level*12 and gs.level<40:
        gs.level+=1;gs.lvlup_t=45;play(SND_LVL)
        gs.popups.append(Popup(GAME_W//2,GAME_H//2-20,f"LVL {gs.level}!",YELLOW,True))

    # Screen shake
    if gs.shake>0:
        gs.shake-=1;gs.sx=random.randint(-3,3);gs.sy=random.randint(-3,3)
    else: gs.sx=gs.sy=0

    # ── Stop lines ──────────────────────────────────────────
    stop_lines=[]
    for tl in gs.lights:  stop_lines.append((tl.stop_line_y,tl.active))
    for zb in gs.zebras:  stop_lines.append((zb.stop_line_y,zb.active and zb.has_ped_on_road()))

    # Player stop warning
    py=gs.player.y
    near_red=any(active and (py-65<sly<py+8) for sly,active in stop_lines)
    if near_red: gs.stop_warn=max(gs.stop_warn,35)
    if gs.stop_warn>0: gs.stop_warn-=1

    # ── Spawn enemies (lane dedup) ───────────────────────────
    gs.sp_t+=1
    sr=max(26,80-gs.level*5)
    if gs.sp_t>=sr:
        gs.sp_t=0
        avail=[l for l in range(N_LANES) if l not in gs._rlanes[-2:]]
        lane=random.choice(avail) if avail else random.randint(0,N_LANES-1)
        gs._rlanes.append(lane)
        if len(gs._rlanes)>5: gs._rlanes.pop(0)
        gs.enemies.append(Enemy(gs.level,lane))

    # ── Spawn coins ─────────────────────────────────────────
    gs.co_t+=1
    if gs.co_t>=70:
        gs.co_t=0
        c=Coin()
        # Avoid spawning on enemy positions
        occupied={int(e.x) for e in gs.enemies if abs(e.y+20)<50}
        if int(c.x) not in occupied: gs.coinlist.append(c)

    # ── Spawn power-ups ─────────────────────────────────────
    gs.pu_t+=1
    if gs.pu_t>=380:
        gs.pu_t=0
        if len(gs.powerups)<2: gs.powerups.append(PowerUp())

    # ── Spawn side peds ─────────────────────────────────────
    gs.pd_t+=1
    if gs.pd_t>=155:
        gs.pd_t=0
        if random.random()<0.6: gs.side_peds.append(SidePed())

    # ── Decorations ─────────────────────────────────────────
    if random.random()<0.0038: gs.signs.append(StopSign())
    gs.lt_t+=1
    if gs.lt_t>=310 and len(gs.lights)<2: gs.lt_t=0;gs.lights.append(TrafficLight())
    gs.zb_t+=1
    if gs.zb_t>=470 and len(gs.zebras)<2: gs.zb_t=0;gs.zebras.append(ZebraCrossing())

    pr=gs.player.rect()

    # ── Update enemies ───────────────────────────────────────
    eff_stop=stop_lines.copy()
    if gs.slow_t>0:
        for e in gs.enemies: e.base_spd*=0.97   # slow decay
    for e in gs.enemies[:]:
        e.update(gs.cam_spd,eff_stop)
        if e.y>GAME_H+44: gs.enemies.remove(e); continue
        if not e.passed and e.y>gs.player.y+22: e.passed=True;gs.score+=10
        if gs.inv<=0 and e.rect().colliderect(pr):
            if gs.cheat or gs.player.shield>0:
                # bounce enemy away
                e.y-=8
                continue
            gs.lives-=1;gs.inv=100;gs.flash_t=28;gs.shake=15
            play(SND_HIT)
            for _ in range(18):
                gs.particles.append(Particle(int(gs.player.x),int(gs.player.y),
                    random.choice([RED,ORANGE,YELLOW,WHITE])))
            if gs.lives<=0:
                gs.game_over=True;gs.cheat_step=0;save_hi(gs.hi)

    # ── Update coins ─────────────────────────────────────────
    mult=2 if gs.coin_x2>0 else 1
    for c in gs.coinlist[:]:
        c.update(gs.cam_spd)
        if c.y>GAME_H+22: gs.coinlist.remove(c); continue
        if c.rect().colliderect(pr):
            gain=50*mult; gs.coins+=mult; gs.score+=gain
            play(SND_COIN); gs.coinlist.remove(c)
            for _ in range(9):
                gs.particles.append(Particle(int(c.x),int(c.y),
                    random.choice([YELLOW,(255,220,70),(255,255,140)]),spd=1.8,life=18))
            gs.popups.append(Popup(int(c.x),int(c.y)-8,f"+{gain}",YELLOW))

    # ── Update power-ups ─────────────────────────────────────
    for pu in gs.powerups[:]:
        pu.update(gs.cam_spd)
        if pu.y>GAME_H+22: gs.powerups.remove(pu); continue
        if pu.rect().colliderect(pr):
            gs.powerups.remove(pu); play(SND_BONUS)
            if pu.kind=='shield':
                gs.player.shield=420
                gs.popups.append(Popup(int(gs.player.x),int(gs.player.y)-20,"SHIELD!",BLUE,True))
            elif pu.kind=='slow':
                gs.slow_t=360
                gs.popups.append(Popup(int(gs.player.x),int(gs.player.y)-20,"SLOW TIME!",(180,80,255),True))
            elif pu.kind=='x2':
                gs.coin_x2=420
                gs.popups.append(Popup(int(gs.player.x),int(gs.player.y)-20,"COINS x2!",YELLOW,True))

    # ── World updates ────────────────────────────────────────
    for s in gs.signs[:]:
        s.update(gs.cam_spd)
        if s.y>GAME_H+32: gs.signs.remove(s)
    for tl in gs.lights[:]:
        tl.update(gs.cam_spd)
        if tl.y>GAME_H+60: gs.lights.remove(tl)
    for zb in gs.zebras[:]:
        zb.update(gs.cam_spd)
        if zb.y>GAME_H+60: gs.zebras.remove(zb)
    for p in gs.side_peds[:]:
        p.update(gs.cam_spd)
        if p.done: gs.side_peds.remove(p)
    for sk in gs.skids[:]:
        sk.update(gs.cam_spd)
        if sk.life<=0: gs.skids.remove(sk)
    for pt in gs.particles[:]:
        pt.update()
        if pt.life<=0: gs.particles.remove(pt)
    for pp in gs.popups[:]:
        pp.update()
        if pp.life<=0: gs.popups.remove(pp)

    if gs.inv>0: gs.inv-=1
    if gs.flash_t>0:
        gs.flash_t-=1;gs.flash=(gs.flash_t%6<3)
    else: gs.flash=False

# ═══════════════════════════════════════════════════════════════
#  DRAW
# ═══════════════════════════════════════════════════════════════
def draw(gs):
    if gs.night:
        canvas.fill((12,12,24))
    else:
        canvas.fill((0,0,0))
    draw_road(canvas,gs.road_off,gs.night)
    for sk in gs.skids:       sk.draw(canvas)
    for s  in gs.signs:       s.draw(canvas)
    for zb in gs.zebras:      zb.draw(canvas,gs.night)
    for tl in gs.lights:      tl.draw(canvas,gs.night)
    for p  in gs.side_peds:   p.draw(canvas)
    for pu in gs.powerups:    pu.draw(canvas)
    for c  in gs.coinlist:    c.draw(canvas)
    for e  in gs.enemies:     e.draw(canvas,gs.night)
    for pt in gs.particles:   pt.draw(canvas)
    if not gs.flash:          gs.player.draw(canvas,gs.night,rmb_held)
    for pp in gs.popups:      pp.draw(canvas)
    draw_hud(canvas,gs)
    if gs.game_over:          draw_game_over(canvas,gs)

# ═══════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════
rmb_held = False   # module-level so draw() can access it

def main():
    global screen, rmb_held   # FIX: declare global so VIDEORESIZE can reassign screen

    hi    = load_hi()
    gs    = None
    title = True
    off   = 0.0
    tick  = 0

    while True:
        clock.tick(FPS); tick+=1
        gmx,_ = game_mouse()
        mb     = pygame.mouse.get_pressed()
        lmb,rmb_held = mb[0], mb[2]

        for ev in pygame.event.get():
            if ev.type==pygame.QUIT:
                if gs: save_hi(gs.hi)
                pygame.quit(); sys.exit()

            # ── Window resize ───────────────────────────────
            if ev.type==pygame.VIDEORESIZE:                 # pygame 1.x
                screen=pygame.display.set_mode(ev.size, pygame.RESIZABLE)
            # pygame 2.x handles resize automatically via get_size()

            if ev.type==pygame.KEYDOWN:
                if ev.key==pygame.K_ESCAPE:
                    if gs: save_hi(gs.hi)
                    pygame.quit(); sys.exit()
                if gs and not gs.game_over and ev.key==pygame.K_p:
                    gs.paused=not gs.paused

            if title:
                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    gs=GS(hi); title=False
            else:
                cheat_event(gs,ev)
                if gs.game_over and ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    hi=gs.hi; gs=GS(hi)

        if title:
            off=(off+1.5)%100000
            canvas.fill((16,16,36))
            draw_title(canvas,off,tick)
        else:
            if not gs.game_over:
                update(gs,gmx,lmb,rmb_held)
            draw(gs)

        blit_canvas(gs.sx if gs else 0, gs.sy if gs else 0)
        pygame.display.flip()

if __name__=="__main__":
    main()
