import pygame
import sys
import random
import math
import os

pygame.init()
pygame.display.set_caption("Rabbit Racer")

GAME_W, GAME_H = 240, 360
SCALE = 3
WIDTH, HEIGHT = GAME_W * SCALE, GAME_H * SCALE

screen = pygame.display.set_mode((WIDTH, HEIGHT))
game_surf = pygame.Surface((GAME_W, GAME_H))
clock = pygame.time.Clock()
FPS = 60

# -- Colors --
BLACK=(0,0,0); WHITE=(255,255,255); GRAY=(128,128,128)
RED=(210,50,50); GREEN=(50,190,50); BLUE=(50,100,210)
YELLOW=(240,210,50); ORANGE=(230,140,40); BROWN=(120,80,30)
SKIN=(255,200,155); PINK=(255,160,190); ROAD_C=(78,78,78)
GRASS_C=(55,150,45); SIDE_C=(145,138,125); CREAM=(230,225,205)
DARK_BROWN=(55,32,10); ROTT_C=(38,28,18); ROTT_TAN=(130,95,42)
CHEAT_COL=(255,60,255)

ROAD_L=42; ROAD_R=198; ROAD_W=ROAD_R-ROAD_L
LANE_W=ROAD_W//3
LANES=[ROAD_L+LANE_W*i+LANE_W//2 for i in range(3)]

CAR_PALETTES=[
    [(200,50,50),(50,50,200),(50,180,50),(200,180,50),(200,100,200)],
    [(200,100,50),(80,50,180),(50,200,200),(180,50,180),(220,220,80)],
    [(220,220,220),(50,50,50),(200,150,50),(100,180,50),(50,150,200)],
    [(255,120,50),(120,50,255),(50,255,180),(255,50,120),(200,255,50)],
]

def pix_font(size=7):
    return pygame.font.SysFont("monospace", size)

def draw_car(surf, cx, cy, color, ctype=0, flipped=False):
    w,h = [(16,24),(18,28),(14,22),(18,26),(16,26)][min(ctype,4)]
    bx=cx-w//2; by=cy-h//2
    roof=tuple(max(0,c-50) for c in color)
    pygame.draw.rect(surf,color,(bx,by+4,w,h-8))
    pygame.draw.rect(surf,roof,(bx+2,by+8,w-4,h-16))
    wc=(160,220,255)
    if flipped:
        pygame.draw.rect(surf,wc,(bx+3,by+h-13,w-6,4))
        pygame.draw.rect(surf,wc,(bx+3,by+8,w-6,4))
        pygame.draw.rect(surf,(255,60,60),(bx+1,by,4,3))
        pygame.draw.rect(surf,(255,60,60),(bx+w-5,by,4,3))
    else:
        pygame.draw.rect(surf,wc,(bx+3,by+8,w-6,4))
        pygame.draw.rect(surf,wc,(bx+3,by+h-13,w-6,4))
        pygame.draw.rect(surf,(255,255,130),(bx+1,by,4,3))
        pygame.draw.rect(surf,(255,255,130),(bx+w-5,by,4,3))
    wh=(25,25,25)
    for wx,wy in [(bx-2,by+4),(bx+w-2,by+4),(bx-2,by+h-11),(bx+w-2,by+h-11)]:
        pygame.draw.rect(surf,wh,(wx,wy,4,7))
    # Hubcaps
    for wx,wy in [(bx-1,by+6),(bx+w-3,by+6),(bx-1,by+h-9),(bx+w-3,by+h-9)]:
        pygame.draw.rect(surf,GRAY,(wx,wy,2,3))

def draw_player_car(surf, cx, cy):
    color=(220,50,50); w,h=20,28
    bx=cx-w//2; by=cy-h//2
    roof=(170,30,30)
    pygame.draw.rect(surf,color,(bx,by+4,w,h-8))
    pygame.draw.rect(surf,roof,(bx+2,by+8,w-4,h-16))
    pygame.draw.rect(surf,(170,225,255),(bx+3,by+8,w-6,4))
    pygame.draw.rect(surf,(170,225,255),(bx+3,by+h-13,w-6,4))
    pygame.draw.rect(surf,(255,255,130),(bx+1,by,4,3))
    pygame.draw.rect(surf,(255,255,130),(bx+w-5,by,4,3))
    pygame.draw.rect(surf,(255,50,50),(bx+1,by+h-3,4,3))
    pygame.draw.rect(surf,(255,50,50),(bx+w-5,by+h-3,4,3))
    wh=(22,22,22)
    for wx2,wy2 in [(bx-2,by+4),(bx+w-2,by+4),(bx-2,by+h-11),(bx+w-2,by+h-11)]:
        pygame.draw.rect(surf,wh,(wx2,wy2,4,7))
    # Rabbit man (left seat)
    rx,ry=cx-4,cy-3
    # Ears
    pygame.draw.rect(surf,CREAM,(rx-1,ry-14,2,7))
    pygame.draw.rect(surf,CREAM,(rx+2,ry-14,2,7))
    pygame.draw.rect(surf,PINK,(rx,ry-13,1,5))
    pygame.draw.rect(surf,PINK,(rx+3,ry-13,1,5))
    # Head
    pygame.draw.rect(surf,CREAM,(rx-2,ry-8,6,6))
    # Eyes
    pygame.draw.rect(surf,(200,50,50),(rx,ry-7,1,1))
    pygame.draw.rect(surf,(200,50,50),(rx+3,ry-7,1,1))
    # Nose
    pygame.draw.rect(surf,PINK,(rx+1,ry-6,2,1))
    # Body
    pygame.draw.rect(surf,BLUE,(rx-2,ry-2,5,5))
    # Rottweiler (right seat)
    dx,dy=cx+4,cy-3
    # Rott body
    pygame.draw.rect(surf,ROTT_C,(dx-3,dy-4,6,5))
    # Rott head
    pygame.draw.rect(surf,ROTT_C,(dx-3,dy-9,6,5))
    # Tan markings on face
    pygame.draw.rect(surf,ROTT_TAN,(dx-2,dy-8,4,2))
    pygame.draw.rect(surf,ROTT_TAN,(dx-2,dy-5,4,2))
    # Eyes
    pygame.draw.rect(surf,(190,150,50),(dx-2,dy-8,1,1))
    pygame.draw.rect(surf,(190,150,50),(dx+1,dy-8,1,1))
    # Floppy ears
    pygame.draw.rect(surf,ROTT_C,(dx-4,dy-9,2,3))
    pygame.draw.rect(surf,ROTT_C,(dx+3,dy-9,2,3))
    # Tan chest
    pygame.draw.rect(surf,ROTT_TAN,(dx-1,dy-3,3,3))

def draw_rabbit_peds(surf, cx, cy, anim, skin_c, shirt_c):
    lo=[0,2,0,-2][anim%4]
    pygame.draw.rect(surf,(40,40,130),(cx-2,cy+2,2,5+lo))
    pygame.draw.rect(surf,(40,40,130),(cx+1,cy+2,2,5-lo))
    pygame.draw.rect(surf,shirt_c,(cx-3,cy-4,6,6))
    pygame.draw.rect(surf,skin_c,(cx-2,cy-9,5,5))
    pygame.draw.rect(surf,skin_c,(cx-4,cy-3+lo,2,4))
    pygame.draw.rect(surf,skin_c,(cx+3,cy-3-lo,2,4))
    # Small head items - hat
    pygame.draw.rect(surf,(80,40,10),(cx-3,cy-11,6,2))
    pygame.draw.rect(surf,(80,40,10),(cx-2,cy-13,4,3))

def draw_stop_sign(surf, cx, cy):
    pygame.draw.rect(surf,GRAY,(cx-1,cy+5,3,14))
    # Octagon via overlapping rects
    pygame.draw.rect(surf,RED,(cx-7,cy-7,14,14))
    pygame.draw.rect(surf,RED,(cx-5,cy-9,10,18))
    pygame.draw.rect(surf,WHITE,(cx-5,cy-5,10,10))
    pygame.draw.rect(surf,WHITE,(cx-3,cy-7,6,14))
    pygame.draw.rect(surf,RED,(cx-4,cy-4,8,8))
    pygame.draw.rect(surf,RED,(cx-2,cy-6,4,12))
    f=pix_font(5)
    t=f.render("STOP",False,WHITE)
    surf.blit(t,(cx-6,cy-2))

def draw_traffic_light(surf, cx, cy, state):
    pygame.draw.rect(surf,GRAY,(cx-1,cy+18,3,20))
    pygame.draw.rect(surf,(28,28,28),(cx-6,cy-18,12,38))
    pygame.draw.rect(surf,(50,50,50),(cx-5,cy-17,10,36))
    rc=RED if state==0 else (55,8,8)
    yc=YELLOW if state==1 else (55,48,8)
    gc=(50,210,50) if state==2 else (8,55,8)
    pygame.draw.rect(surf,rc,(cx-4,cy-15,8,8))
    pygame.draw.rect(surf,yc,(cx-4,cy-4,8,8))
    pygame.draw.rect(surf,gc,(cx-4,cy+7,8,8))

def draw_road(surf, offset):
    pygame.draw.rect(surf,SIDE_C,(0,0,ROAD_L,GAME_H))
    pygame.draw.rect(surf,SIDE_C,(ROAD_R,0,GAME_W-ROAD_R,GAME_H))
    pygame.draw.rect(surf,ROAD_C,(ROAD_L,0,ROAD_W,GAME_H))
    pygame.draw.rect(surf,WHITE,(ROAD_L,0,3,GAME_H))
    pygame.draw.rect(surf,WHITE,(ROAD_R-3,0,3,GAME_H))
    pygame.draw.rect(surf,(150,140,130),(ROAD_L-6,0,6,GAME_H))
    pygame.draw.rect(surf,(150,140,130),(ROAD_R,0,6,GAME_H))
    # Dashed lane lines
    dash_h=14; gap=8; tot=dash_h+gap
    for lane in range(1,3):
        lx=ROAD_L+LANE_W*lane-1
        y=-(offset%tot)
        while y<GAME_H:
            pygame.draw.rect(surf,YELLOW,(lx,int(y),2,dash_h))
            y+=tot
    # Sidewalk tiles
    for y2 in range(0,GAME_H,16):
        yo=(y2-offset%16)%GAME_H
        pygame.draw.rect(surf,(120,112,100),(0,int(yo),ROAD_L,1))
        pygame.draw.rect(surf,(120,112,100),(ROAD_R,int(yo),GAME_W-ROAD_R,1))
    # Grass strip
    pygame.draw.rect(surf,GRASS_C,(0,0,6,GAME_H))
    pygame.draw.rect(surf,GRASS_C,(GAME_W-6,0,6,GAME_H))

def draw_hud(surf, gs):
    f=pix_font(7)
    surf.blit(f.render(f"SC:{gs.score}",False,WHITE),(2,2))
    surf.blit(f.render(f"C:{gs.coins}",False,YELLOW),(2,11))
    surf.blit(f.render(f"L:{gs.level}",False,(100,255,100)),(GAME_W-30,2))
    for i in range(min(gs.lives,9)):
        hx=2+i*11; hy=21
        for hpx in [(1,0,3),(5,0,3),(0,1,9),(1,4,7),(2,5,5),(3,6,3),(4,7,1)]:
            pygame.draw.rect(surf,RED,(hx+hpx[0],hy+hpx[1],hpx[2],1))
    if gs.cheat:
        surf.blit(f.render("CHEAT!",False,CHEAT_COL),(GAME_W//2-18,2))

def draw_game_over(surf, gs):
    ov=pygame.Surface((GAME_W,GAME_H),pygame.SRCALPHA)
    ov.fill((0,0,0,160)); surf.blit(ov,(0,0))
    fb=pix_font(11); fs=pix_font(7)
    t=fb.render("GAME OVER",False,RED)
    surf.blit(t,(GAME_W//2-t.get_width()//2,GAME_H//2-50))
    for i,(txt,col) in enumerate([(f"SCORE: {gs.score}",WHITE),(f"COINS: {gs.coins}",YELLOW),(f"LEVEL: {gs.level}",(100,255,100)),("CLICK TO PLAY",WHITE)]):
        tx=fs.render(txt,False,col)
        surf.blit(tx,(GAME_W//2-tx.get_width()//2,GAME_H//2-25+i*12))

def draw_title(surf, tick):
    surf.fill((20,20,40))
    # Road preview
    draw_road(surf,tick*2)
    # Title box
    ov=pygame.Surface((GAME_W,GAME_H),pygame.SRCALPHA)
    ov.fill((0,0,20,170)); surf.blit(ov,(0,0))
    fb=pix_font(12); fs=pix_font(7); ft=pix_font(6)
    t=fb.render("RABBIT",False,YELLOW)
    surf.blit(t,(GAME_W//2-t.get_width()//2,50))
    t2=fb.render("RACER",False,YELLOW)
    surf.blit(t2,(GAME_W//2-t2.get_width()//2,68))
    draw_player_car(surf,GAME_W//2,120)
    for lbl,col,y2 in [("MOUSE TO STEER",WHITE,155),("DODGE CARS & GRAB COINS",YELLOW,167),("CLICK TO START",(100,255,100),185)]:
        tx=fs.render(lbl,False,col)
        surf.blit(tx,(GAME_W//2-tx.get_width()//2,y2))
    tx=ft.render("CHEAT: MWHEEL x5 + SCROLL UP",False,(180,180,255))
    surf.blit(tx,(GAME_W//2-tx.get_width()//2,210))

class Player:
    def __init__(self):
        self.x=float(GAME_W//2); self.y=GAME_H-55
        self.tx=self.x; self.w=20; self.h=28
    def update(self,mx):
        gx=mx//SCALE
        gx=max(ROAD_L+self.w//2+3,min(ROAD_R-self.w//2-3,gx))
        self.tx=gx; self.x+=(self.tx-self.x)*0.18
    def rect(self):
        return pygame.Rect(int(self.x)-self.w//2+3,self.y-self.h//2+3,self.w-6,self.h-6)
    def draw(self,surf):
        draw_player_car(surf,int(self.x),self.y)

class Enemy:
    def __init__(self,lvl):
        self.lane=random.randint(0,2)
        self.x=float(LANES[self.lane]); self.y=-32.0
        self.w=18; self.h=26
        pal=CAR_PALETTES[min(lvl-1,len(CAR_PALETTES)-1)]
        self.color=random.choice(pal)
        self.ctype=random.randint(0,min(lvl,4))
        self.spd=random.uniform(1.5,2.8+(lvl-1)*0.4)
        self.passed=False
    def update(self,spd):
        self.y+=self.spd+spd*0.6
    def rect(self):
        return pygame.Rect(int(self.x)-self.w//2+2,int(self.y)-self.h//2+2,self.w-4,self.h-4)
    def draw(self,surf):
        draw_car(surf,int(self.x),int(self.y),self.color,self.ctype,True)

class Coin:
    def __init__(self):
        self.x=float(LANES[random.randint(0,2)]+random.randint(-8,8))
        self.y=-12.0; self.r=4; self.anim=0
    def update(self,spd):
        self.y+=1.8+spd*0.5; self.anim=(self.anim+1)%8
    def rect(self):
        return pygame.Rect(int(self.x)-self.r,int(self.y)-self.r,self.r*2,self.r*2)
    def draw(self,surf):
        cx,cy=int(self.x),int(self.y); off=1 if self.anim<4 else 0
        pygame.draw.rect(surf,(210,190,45),(cx-3,cy-4+off,6,7))
        pygame.draw.rect(surf,(255,240,100),(cx-2,cy-5+off,4,1))
        pygame.draw.rect(surf,(255,240,100),(cx-2,cy+2+off,4,1))
        pygame.draw.rect(surf,(170,150,25),(cx-4,cy-2+off,1,3))
        pygame.draw.rect(surf,(170,150,25),(cx+3,cy-2+off,1,3))
        pygame.draw.rect(surf,(170,140,20),(cx-1,cy-3+off,2,5))

class StopSign:
    def __init__(self):
        self.x=random.choice([ROAD_L-14,ROAD_R+14])
        self.y=float(random.randint(-80,-40))
    def update(self,spd):
        self.y+=1.8+spd*0.5
    def draw(self,surf):
        draw_stop_sign(surf,int(self.x),int(self.y))

class TrafficLight:
    def __init__(self):
        self.x=random.choice([ROAD_L-12,ROAD_R+12])
        self.y=float(random.randint(-100,-60))
        self.state=random.randint(0,2)
        self.stimer=0
        self.durations=[220,80,180]
    def update(self,spd):
        self.y+=1.6+spd*0.45
        self.stimer+=1
        if self.stimer>self.durations[self.state]:
            self.state=(self.state+1)%3
            self.stimer=0
    def draw(self,surf):
        draw_traffic_light(surf,int(self.x),int(self.y),self.state)

class Pedestrian:
    SHIRTS=[RED,BLUE,GREEN,YELLOW,ORANGE,(180,50,180),(50,200,200)]
    SKINS=[SKIN,(205,160,105),(145,105,62),(255,225,185)]
    def __init__(self):
        sd=random.choice([-1,1])
        self.x=float(ROAD_L-18 if sd==-1 else ROAD_R+18)
        self.y=float(random.randint(60,GAME_H-80))
        self.dir=sd; self.spd=random.uniform(0.3,0.65)
        self.anim=0; self.atimer=0
        self.waiting=True; self.wtimer=random.randint(40,160)
        self.done=False
        self.skin=random.choice(self.SKINS)
        self.shirt=random.choice(self.SHIRTS)
    def update(self):
        if self.waiting:
            self.wtimer-=1
            if self.wtimer<=0: self.waiting=False
        else:
            self.x+=self.spd*self.dir
            self.atimer+=1
            if self.atimer>=7:
                self.anim=(self.anim+1)%4; self.atimer=0
            if (self.dir==1 and self.x>ROAD_R+25) or (self.dir==-1 and self.x<ROAD_L-25):
                self.done=True
    def draw(self,surf):
        draw_rabbit_peds(surf,int(self.x),int(self.y),self.anim,self.skin,self.shirt)

class GameState:
    def __init__(self):
        self.score=0; self.coins=0; self.level=1; self.lives=3
        self.gspd=2.0; self.road_off=0.0
        self.player=Player()
        self.enemies=[]; self.coins_=[]
        self.peds=[]; self.signs=[]; self.lights=[]
        self.sp_t=0; self.co_t=0; self.pd_t=0
        self.inv=0; self.flash=False; self.flash_t=0
        self.game_over=False
        self.cheat=False; self.sc_clicks=0; self.sc_last=0; self.cheat_step=0

def check_cheat(gs, event):
    now=pygame.time.get_ticks()
    if event.type==pygame.MOUSEBUTTONDOWN and event.button==2:
        if now-gs.sc_last>4000: gs.sc_clicks=0
        gs.sc_clicks+=1; gs.sc_last=now
        if gs.sc_clicks>=5: gs.cheat_step=1
    if gs.cheat_step==1 and event.type==pygame.MOUSEWHEEL and event.y>0:
        gs.cheat=not gs.cheat; gs.cheat_step=0; gs.sc_clicks=0
        if gs.cheat:
            gs.coins+=999; gs.lives=99; gs.score+=9999

def update_game(gs, mx):
    gs.player.update(mx)
    gs.gspd=2.0+(gs.level-1)*0.5
    if gs.cheat: gs.gspd=max(1.0,gs.gspd-1.2)
    gs.road_off=(gs.road_off+gs.gspd)%10000
    gs.score+=1
    if gs.coins>=gs.level*12 and gs.level<20:
        gs.coins-=gs.level*12
        gs.level+=1
    # Spawn enemies
    gs.sp_t+=1; sr=max(35,85-gs.level*5)
    if gs.sp_t>=sr:
        gs.sp_t=0; gs.enemies.append(Enemy(gs.level))
    # Spawn coins
    gs.co_t+=1
    if gs.co_t>=80: gs.co_t=0; gs.coins_.append(Coin())
    # Spawn pedestrians
    gs.pd_t+=1
    if gs.pd_t>=170:
        gs.pd_t=0
        if random.random()<0.5: gs.peds.append(Pedestrian())
    # Random decorations
    if random.random()<0.004: gs.signs.append(StopSign())
    if random.random()<0.003: gs.lights.append(TrafficLight())
    # Update
    pr=gs.player.rect()
    for e in gs.enemies[:]:
        e.update(gs.gspd)
        if e.y>GAME_H+40: gs.enemies.remove(e); continue
        if not e.passed and e.y>gs.player.y+20: e.passed=True
        if gs.inv<=0 and e.rect().colliderect(pr):
            if not gs.cheat:
                gs.lives-=1; gs.inv=110; gs.flash_t=28
                if gs.lives<=0: gs.game_over=True
    for c in gs.coins_[:]:
        c.update(gs.gspd)
        if c.y>GAME_H+20: gs.coins_.remove(c); continue
        if c.rect().colliderect(pr):
            gs.coins+=1; gs.score+=50; gs.coins_.remove(c)
    for p in gs.peds[:]:
        p.update()
        if p.done: gs.peds.remove(p)
    for s in gs.signs[:]:
        s.update(gs.gspd)
        if s.y>GAME_H+30: gs.signs.remove(s)
    for tl in gs.lights[:]:
        tl.update(gs.gspd)
        if tl.y>GAME_H+50: gs.lights.remove(tl)
    if gs.inv>0: gs.inv-=1
    if gs.flash_t>0:
        gs.flash_t-=1; gs.flash=(gs.flash_t%6<3)
    else:
        gs.flash=False

def draw_game(gs):
    draw_road(game_surf,gs.road_off)
    for s in gs.signs: s.draw(game_surf)
    for tl in gs.lights: tl.draw(game_surf)
    for p in gs.peds: p.draw(game_surf)
    for c in gs.coins_: c.draw(game_surf)
    for e in gs.enemies: e.draw(game_surf)
    if not gs.flash: gs.player.draw(game_surf)
    draw_hud(game_surf,gs)
    if gs.game_over: draw_game_over(game_surf,gs)

def main():
    gs=None; title=True; tick=0
    while True:
        clock.tick(FPS); tick+=1
        mx,_=pygame.mouse.get_pos()
        for ev in pygame.event.get():
            if ev.type==pygame.QUIT or (ev.type==pygame.KEYDOWN and ev.key==pygame.K_ESCAPE):
                pygame.quit(); sys.exit()
            if title:
                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    gs=GameState(); title=False
            else:
                check_cheat(gs,ev)
                if gs.game_over and ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    gs=GameState()
        if title:
            game_surf.fill((20,20,40))
            draw_title(game_surf,tick)
        else:
            game_surf.fill(BLACK)
            if not gs.game_over: update_game(gs,mx)
            draw_game(gs)
        pygame.transform.scale(game_surf,(WIDTH,HEIGHT),screen)
        pygame.display.flip()

if __name__=="__main__":
    main()